# Changelog

## 0.3.0

- Prevent race condition reading secrets on startup
- Update to Alpine 3.19

## 0.2.0

- Update to Alpine 3.17
- Mark add-on as stable
- Use new s6-overlay

## 0.1.3

- Correct port on discovery

## 0.1.2

- Revert restart nginx service on error

## 0.1.1

- Restart nginx service on error

## 0.1.0

- Initial release
