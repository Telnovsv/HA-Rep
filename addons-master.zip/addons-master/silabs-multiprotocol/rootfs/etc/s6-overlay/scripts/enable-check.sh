#!/bin/sh

/etc/s6-overlay/scripts/otbr-enable-check.sh
/etc/s6-overlay/scripts/socat-cpcd-tcp-enable-check.sh
