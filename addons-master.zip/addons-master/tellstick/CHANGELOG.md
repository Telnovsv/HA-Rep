# Changelog

## 2.2.0

**Deprecation notice**
This will be the final update for this addon. The library it depends on is abandoned.
It's last activity was 5 years ago it it cannot be built on alpine >3.15. Users
can continue to use it but no issues or PRs will be accepted for it going forward.

- Use Alpine 3.15

## 2.1.0

- Update hardware configuration for Supervisor 2021.02.5
- Use Alpine 3.13

## 2.0.0

- Rewrites add-on onto Bashio
- Added documentation to the add-on repository
- Code formatting

## 1.0.0

- Update base image

## 0.5.0

- Added possibility for config options:
  protocols: comen, fineoffset, mandolyn, oregon
  models: temperature, temperaturehumidity
- Created changelog
